def run():
    print('I am a script')
